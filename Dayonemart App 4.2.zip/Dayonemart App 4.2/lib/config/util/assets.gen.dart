// dart format width=80

/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: deprecated_member_use,directives_ordering,implicit_dynamic_list_literal,unnecessary_import

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart' as _svg;
import 'package:vector_graphics/vector_graphics.dart' as _vg;

class $AssetsImagesGen {
  const $AssetsImagesGen();

  /// File path: assets/images/bg1.png
  AssetGenImage get bg1 => const AssetGenImage('assets/images/bg1.png');

  /// File path: assets/images/bg2.png
  AssetGenImage get bg2 => const AssetGenImage('assets/images/bg2.png');

  /// File path: assets/images/bg3.png
  AssetGenImage get bg3 => const AssetGenImage('assets/images/bg3.png');

  /// Directory path: assets/images/gif
  $AssetsImagesGifGen get gif => const $AssetsImagesGifGen();

  /// File path: assets/images/halal.png
  AssetGenImage get halal => const AssetGenImage('assets/images/halal.png');

  /// File path: assets/images/logo.png
  AssetGenImage get logo => const AssetGenImage('assets/images/logo.png');

  /// File path: assets/images/marker.png
  AssetGenImage get marker => const AssetGenImage('assets/images/marker.png');

  /// File path: assets/images/no_internet.png
  AssetGenImage get noInternet =>
      const AssetGenImage('assets/images/no_internet.png');

  /// File path: assets/images/percentage.png
  AssetGenImage get percentage =>
      const AssetGenImage('assets/images/percentage.png');

  /// File path: assets/images/placeholder.jpg
  AssetGenImage get placeholder =>
      const AssetGenImage('assets/images/placeholder.jpg');

  /// Directory path: assets/images/svg
  $AssetsImagesSvgGen get svg => const $AssetsImagesSvgGen();

  /// File path: assets/images/wallet.png
  AssetGenImage get wallet => const AssetGenImage('assets/images/wallet.png');

  /// List of all assets
  List<AssetGenImage> get values => [
    bg1,
    bg2,
    bg3,
    halal,
    logo,
    marker,
    noInternet,
    percentage,
    placeholder,
    wallet,
  ];
}

class $AssetsJsonGen {
  const $AssetsJsonGen();

  /// File path: assets/json/map-picker-1.json
  String get mapPicker1 => 'assets/json/map-picker-1.json';

  /// File path: assets/json/map-picker-2.json
  String get mapPicker2 => 'assets/json/map-picker-2.json';

  /// List of all assets
  List<String> get values => [mapPicker1, mapPicker2];
}

class $AssetsImagesGifGen {
  const $AssetsImagesGifGen();

  /// File path: assets/images/gif/cooking_logo.gif
  AssetGenImage get cookingLogo =>
      const AssetGenImage('assets/images/gif/cooking_logo.gif');

  /// File path: assets/images/gif/on_the_way.gif
  AssetGenImage get onTheWay =>
      const AssetGenImage('assets/images/gif/on_the_way.gif');

  /// File path: assets/images/gif/order_pending_logo.gif
  AssetGenImage get orderPendingLogo =>
      const AssetGenImage('assets/images/gif/order_pending_logo.gif');

  /// List of all assets
  List<AssetGenImage> get values => [cookingLogo, onTheWay, orderPendingLogo];
}

class $AssetsImagesSvgGen {
  const $AssetsImagesSvgGen();

  /// File path: assets/images/svg/account_active.svg
  SvgGenImage get accountActive =>
      const SvgGenImage('assets/images/svg/account_active.svg');

  /// File path: assets/images/svg/account_inactive.svg
  SvgGenImage get accountInactive =>
      const SvgGenImage('assets/images/svg/account_inactive.svg');

  /// File path: assets/images/svg/add-circle.svg
  SvgGenImage get addCircle =>
      const SvgGenImage('assets/images/svg/add-circle.svg');

  /// File path: assets/images/svg/apple-light.svg
  SvgGenImage get appleLight =>
      const SvgGenImage('assets/images/svg/apple-light.svg');

  /// File path: assets/images/svg/apple.svg
  SvgGenImage get apple => const SvgGenImage('assets/images/svg/apple.svg');

  /// File path: assets/images/svg/camera.svg
  SvgGenImage get camera => const SvgGenImage('assets/images/svg/camera.svg');

  /// File path: assets/images/svg/cart_active.svg
  SvgGenImage get cartActive =>
      const SvgGenImage('assets/images/svg/cart_active.svg');

  /// File path: assets/images/svg/cart_inactive.svg
  SvgGenImage get cartInactive =>
      const SvgGenImage('assets/images/svg/cart_inactive.svg');

  /// File path: assets/images/svg/cart_inactive_menu.svg
  SvgGenImage get cartInactiveMenu =>
      const SvgGenImage('assets/images/svg/cart_inactive_menu.svg');

  /// File path: assets/images/svg/categories.svg
  SvgGenImage get categories =>
      const SvgGenImage('assets/images/svg/categories.svg');

  /// File path: assets/images/svg/categories_active.svg
  SvgGenImage get categoriesActive =>
      const SvgGenImage('assets/images/svg/categories_active.svg');

  /// File path: assets/images/svg/circle-microphone-red.svg
  SvgGenImage get circleMicrophoneRed =>
      const SvgGenImage('assets/images/svg/circle-microphone-red.svg');

  /// File path: assets/images/svg/circle-microphone.svg
  SvgGenImage get circleMicrophone =>
      const SvgGenImage('assets/images/svg/circle-microphone.svg');

  /// File path: assets/images/svg/circle-star.svg
  SvgGenImage get circleStar =>
      const SvgGenImage('assets/images/svg/circle-star.svg');

  /// File path: assets/images/svg/circle_star_outline.svg
  SvgGenImage get circleStarOutline =>
      const SvgGenImage('assets/images/svg/circle_star_outline.svg');

  /// File path: assets/images/svg/cloud-upload.svg
  SvgGenImage get cloudUpload =>
      const SvgGenImage('assets/images/svg/cloud-upload.svg');

  /// File path: assets/images/svg/coin_negative.svg
  SvgGenImage get coinNegative =>
      const SvgGenImage('assets/images/svg/coin_negative.svg');

  /// File path: assets/images/svg/coin_positive.svg
  SvgGenImage get coinPositive =>
      const SvgGenImage('assets/images/svg/coin_positive.svg');

  /// File path: assets/images/svg/contact_us.svg
  SvgGenImage get contactUs =>
      const SvgGenImage('assets/images/svg/contact_us.svg');

  /// File path: assets/images/svg/coupon_percentage.svg
  SvgGenImage get couponPercentage =>
      const SvgGenImage('assets/images/svg/coupon_percentage.svg');

  /// File path: assets/images/svg/currency-exchange.svg
  SvgGenImage get currencyExchange =>
      const SvgGenImage('assets/images/svg/currency-exchange.svg');

  /// File path: assets/images/svg/dotted.svg
  SvgGenImage get dotted => const SvgGenImage('assets/images/svg/dotted.svg');

  /// File path: assets/images/svg/duplicate.svg
  SvgGenImage get duplicate =>
      const SvgGenImage('assets/images/svg/duplicate.svg');

  /// File path: assets/images/svg/edit.svg
  SvgGenImage get edit => const SvgGenImage('assets/images/svg/edit.svg');

  /// File path: assets/images/svg/empty-order.svg
  SvgGenImage get emptyOrder =>
      const SvgGenImage('assets/images/svg/empty-order.svg');

  /// File path: assets/images/svg/exclamation.svg
  SvgGenImage get exclamation =>
      const SvgGenImage('assets/images/svg/exclamation.svg');

  /// File path: assets/images/svg/eye-crossed.svg
  SvgGenImage get eyeCrossed =>
      const SvgGenImage('assets/images/svg/eye-crossed.svg');

  /// File path: assets/images/svg/facebook.svg
  SvgGenImage get facebook =>
      const SvgGenImage('assets/images/svg/facebook.svg');

  /// File path: assets/images/svg/faq.svg
  SvgGenImage get faq => const SvgGenImage('assets/images/svg/faq.svg');

  /// File path: assets/images/svg/faq_cover.svg
  SvgGenImage get faqCover =>
      const SvgGenImage('assets/images/svg/faq_cover.svg');

  /// File path: assets/images/svg/favourite.svg
  SvgGenImage get favourite =>
      const SvgGenImage('assets/images/svg/favourite.svg');

  /// File path: assets/images/svg/file-download.svg
  SvgGenImage get fileDownload =>
      const SvgGenImage('assets/images/svg/file-download.svg');

  /// Directory path: assets/images/svg/flags
  $AssetsImagesSvgFlagsGen get flags => const $AssetsImagesSvgFlagsGen();

  /// File path: assets/images/svg/flash.svg
  SvgGenImage get flash => const SvgGenImage('assets/images/svg/flash.svg');

  /// File path: assets/images/svg/forget_password.svg
  SvgGenImage get forgetPassword =>
      const SvgGenImage('assets/images/svg/forget_password.svg');

  /// File path: assets/images/svg/gift.svg
  SvgGenImage get gift => const SvgGenImage('assets/images/svg/gift.svg');

  /// File path: assets/images/svg/globe.svg
  SvgGenImage get globe => const SvgGenImage('assets/images/svg/globe.svg');

  /// File path: assets/images/svg/gmail.svg
  SvgGenImage get gmail => const SvgGenImage('assets/images/svg/gmail.svg');

  /// File path: assets/images/svg/google.svg
  SvgGenImage get google => const SvgGenImage('assets/images/svg/google.svg');

  /// File path: assets/images/svg/grocery.svg
  SvgGenImage get grocery => const SvgGenImage('assets/images/svg/grocery.svg');

  /// File path: assets/images/svg/home_active.svg
  SvgGenImage get homeActive =>
      const SvgGenImage('assets/images/svg/home_active.svg');

  /// File path: assets/images/svg/home_inactive.svg
  SvgGenImage get homeInactive =>
      const SvgGenImage('assets/images/svg/home_inactive.svg');

  /// File path: assets/images/svg/image.svg
  SvgGenImage get image => const SvgGenImage('assets/images/svg/image.svg');

  /// File path: assets/images/svg/images.svg
  SvgGenImage get images => const SvgGenImage('assets/images/svg/images.svg');

  /// File path: assets/images/svg/info.svg
  SvgGenImage get info => const SvgGenImage('assets/images/svg/info.svg');

  /// File path: assets/images/svg/left-arrow.svg
  SvgGenImage get leftArrow =>
      const SvgGenImage('assets/images/svg/left-arrow.svg');

  /// File path: assets/images/svg/lock.svg
  SvgGenImage get lock => const SvgGenImage('assets/images/svg/lock.svg');

  /// File path: assets/images/svg/login-with-key.svg
  SvgGenImage get loginWithKey =>
      const SvgGenImage('assets/images/svg/login-with-key.svg');

  /// File path: assets/images/svg/login_password.svg
  SvgGenImage get loginPassword =>
      const SvgGenImage('assets/images/svg/login_password.svg');

  /// File path: assets/images/svg/logout.svg
  SvgGenImage get logout => const SvgGenImage('assets/images/svg/logout.svg');

  /// File path: assets/images/svg/loyalty-program.svg
  SvgGenImage get loyaltyProgram =>
      const SvgGenImage('assets/images/svg/loyalty-program.svg');

  /// File path: assets/images/svg/loyalty_point.svg
  SvgGenImage get loyaltyPoint =>
      const SvgGenImage('assets/images/svg/loyalty_point.svg');

  /// File path: assets/images/svg/marker3.svg
  SvgGenImage get marker3 => const SvgGenImage('assets/images/svg/marker3.svg');

  /// File path: assets/images/svg/messages.svg
  SvgGenImage get messages =>
      const SvgGenImage('assets/images/svg/messages.svg');

  /// File path: assets/images/svg/mic.svg
  SvgGenImage get mic => const SvgGenImage('assets/images/svg/mic.svg');

  /// File path: assets/images/svg/minus-circle.svg
  SvgGenImage get minusCircle =>
      const SvgGenImage('assets/images/svg/minus-circle.svg');

  /// File path: assets/images/svg/moon.svg
  SvgGenImage get moon => const SvgGenImage('assets/images/svg/moon.svg');

  /// File path: assets/images/svg/non-veg.svg
  SvgGenImage get nonVeg => const SvgGenImage('assets/images/svg/non-veg.svg');

  /// File path: assets/images/svg/notifications.svg
  SvgGenImage get notifications =>
      const SvgGenImage('assets/images/svg/notifications.svg');

  /// File path: assets/images/svg/offer_active.svg
  SvgGenImage get offerActive =>
      const SvgGenImage('assets/images/svg/offer_active.svg');

  /// File path: assets/images/svg/order.svg
  SvgGenImage get order => const SvgGenImage('assets/images/svg/order.svg');

  /// File path: assets/images/svg/order_confirmation.svg
  SvgGenImage get orderConfirmation =>
      const SvgGenImage('assets/images/svg/order_confirmation.svg');

  /// File path: assets/images/svg/password_lock.svg
  SvgGenImage get passwordLock =>
      const SvgGenImage('assets/images/svg/password_lock.svg');

  /// File path: assets/images/svg/pdf_button.svg
  SvgGenImage get pdfButton =>
      const SvgGenImage('assets/images/svg/pdf_button.svg');

  /// File path: assets/images/svg/pharmacy.svg
  SvgGenImage get pharmacy =>
      const SvgGenImage('assets/images/svg/pharmacy.svg');

  /// File path: assets/images/svg/phone-call-icon.svg
  SvgGenImage get phoneCallIcon =>
      const SvgGenImage('assets/images/svg/phone-call-icon.svg');

  /// File path: assets/images/svg/phone-call.svg
  SvgGenImage get phoneCall =>
      const SvgGenImage('assets/images/svg/phone-call.svg');

  /// File path: assets/images/svg/pin.svg
  SvgGenImage get pin => const SvgGenImage('assets/images/svg/pin.svg');

  /// File path: assets/images/svg/prescription.svg
  SvgGenImage get prescription =>
      const SvgGenImage('assets/images/svg/prescription.svg');

  /// File path: assets/images/svg/privacy_policy.svg
  SvgGenImage get privacyPolicy =>
      const SvgGenImage('assets/images/svg/privacy_policy.svg');

  /// File path: assets/images/svg/profile.svg
  SvgGenImage get profile => const SvgGenImage('assets/images/svg/profile.svg');

  /// File path: assets/images/svg/profile_avatar_gray.svg
  SvgGenImage get profileAvatarGray =>
      const SvgGenImage('assets/images/svg/profile_avatar_gray.svg');

  /// File path: assets/images/svg/receive-mail.svg
  SvgGenImage get receiveMail =>
      const SvgGenImage('assets/images/svg/receive-mail.svg');

  /// File path: assets/images/svg/refer_earn.svg
  SvgGenImage get referEarn =>
      const SvgGenImage('assets/images/svg/refer_earn.svg');

  /// File path: assets/images/svg/refund_policy.svg
  SvgGenImage get refundPolicy =>
      const SvgGenImage('assets/images/svg/refund_policy.svg');

  /// File path: assets/images/svg/rightArrow.svg
  SvgGenImage get rightArrow =>
      const SvgGenImage('assets/images/svg/rightArrow.svg');

  /// File path: assets/images/svg/search.svg
  SvgGenImage get search => const SvgGenImage('assets/images/svg/search.svg');

  /// File path: assets/images/svg/search_result_no_data.svg
  SvgGenImage get searchResultNoData =>
      const SvgGenImage('assets/images/svg/search_result_no_data.svg');

  /// File path: assets/images/svg/send.svg
  SvgGenImage get send => const SvgGenImage('assets/images/svg/send.svg');

  /// File path: assets/images/svg/setting.svg
  SvgGenImage get setting => const SvgGenImage('assets/images/svg/setting.svg');

  /// File path: assets/images/svg/settings-sliders.svg
  SvgGenImage get settingsSliders =>
      const SvgGenImage('assets/images/svg/settings-sliders.svg');

  /// File path: assets/images/svg/shield-trust.svg
  SvgGenImage get shieldTrust =>
      const SvgGenImage('assets/images/svg/shield-trust.svg');

  /// File path: assets/images/svg/shop.svg
  SvgGenImage get shop => const SvgGenImage('assets/images/svg/shop.svg');

  /// File path: assets/images/svg/smile.svg
  SvgGenImage get smile => const SvgGenImage('assets/images/svg/smile.svg');

  /// File path: assets/images/svg/sun.svg
  SvgGenImage get sun => const SvgGenImage('assets/images/svg/sun.svg');

  /// File path: assets/images/svg/support.svg
  SvgGenImage get support => const SvgGenImage('assets/images/svg/support.svg');

  /// File path: assets/images/svg/terms_conditions.svg
  SvgGenImage get termsConditions =>
      const SvgGenImage('assets/images/svg/terms_conditions.svg');

  /// File path: assets/images/svg/track_order.svg
  SvgGenImage get trackOrder =>
      const SvgGenImage('assets/images/svg/track_order.svg');

  /// File path: assets/images/svg/track_order_inactive.svg
  SvgGenImage get trackOrderInactive =>
      const SvgGenImage('assets/images/svg/track_order_inactive.svg');

  /// File path: assets/images/svg/triangle-warning.svg
  SvgGenImage get triangleWarning =>
      const SvgGenImage('assets/images/svg/triangle-warning.svg');

  /// File path: assets/images/svg/trush.svg
  SvgGenImage get trush => const SvgGenImage('assets/images/svg/trush.svg');

  /// File path: assets/images/svg/trush_menu.svg
  SvgGenImage get trushMenu =>
      const SvgGenImage('assets/images/svg/trush_menu.svg');

  /// File path: assets/images/svg/veg.svg
  SvgGenImage get veg => const SvgGenImage('assets/images/svg/veg.svg');

  /// File path: assets/images/svg/verify_phone.svg
  SvgGenImage get verifyPhone =>
      const SvgGenImage('assets/images/svg/verify_phone.svg');

  /// File path: assets/images/svg/visibility.svg
  SvgGenImage get visibility =>
      const SvgGenImage('assets/images/svg/visibility.svg');

  /// File path: assets/images/svg/wallet.svg
  SvgGenImage get wallet => const SvgGenImage('assets/images/svg/wallet.svg');

  /// File path: assets/images/svg/wishlist_no_data.svg
  SvgGenImage get wishlistNoData =>
      const SvgGenImage('assets/images/svg/wishlist_no_data.svg');

  /// File path: assets/images/svg/wishlist_remove_all.svg
  SvgGenImage get wishlistRemoveAll =>
      const SvgGenImage('assets/images/svg/wishlist_remove_all.svg');

  /// File path: assets/images/svg/yahoo.svg
  SvgGenImage get yahoo => const SvgGenImage('assets/images/svg/yahoo.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    accountActive,
    accountInactive,
    addCircle,
    appleLight,
    apple,
    camera,
    cartActive,
    cartInactive,
    cartInactiveMenu,
    categories,
    categoriesActive,
    circleMicrophoneRed,
    circleMicrophone,
    circleStar,
    circleStarOutline,
    cloudUpload,
    coinNegative,
    coinPositive,
    contactUs,
    couponPercentage,
    currencyExchange,
    dotted,
    duplicate,
    edit,
    emptyOrder,
    exclamation,
    eyeCrossed,
    facebook,
    faq,
    faqCover,
    favourite,
    fileDownload,
    flash,
    forgetPassword,
    gift,
    globe,
    gmail,
    google,
    grocery,
    homeActive,
    homeInactive,
    image,
    images,
    info,
    leftArrow,
    lock,
    loginWithKey,
    loginPassword,
    logout,
    loyaltyProgram,
    loyaltyPoint,
    marker3,
    messages,
    mic,
    minusCircle,
    moon,
    nonVeg,
    notifications,
    offerActive,
    order,
    orderConfirmation,
    passwordLock,
    pdfButton,
    pharmacy,
    phoneCallIcon,
    phoneCall,
    pin,
    prescription,
    privacyPolicy,
    profile,
    profileAvatarGray,
    receiveMail,
    referEarn,
    refundPolicy,
    rightArrow,
    search,
    searchResultNoData,
    send,
    setting,
    settingsSliders,
    shieldTrust,
    shop,
    smile,
    sun,
    support,
    termsConditions,
    trackOrder,
    trackOrderInactive,
    triangleWarning,
    trush,
    trushMenu,
    veg,
    verifyPhone,
    visibility,
    wallet,
    wishlistNoData,
    wishlistRemoveAll,
    yahoo,
  ];
}

class $AssetsImagesSvgFlagsGen {
  const $AssetsImagesSvgFlagsGen();

  /// File path: assets/images/svg/flags/ar.svg
  SvgGenImage get ar => const SvgGenImage('assets/images/svg/flags/ar.svg');

  /// File path: assets/images/svg/flags/bn.svg
  SvgGenImage get bn => const SvgGenImage('assets/images/svg/flags/bn.svg');

  /// File path: assets/images/svg/flags/el.svg
  SvgGenImage get el => const SvgGenImage('assets/images/svg/flags/el.svg');

  /// File path: assets/images/svg/flags/en.svg
  SvgGenImage get en => const SvgGenImage('assets/images/svg/flags/en.svg');

  /// File path: assets/images/svg/flags/es.svg
  SvgGenImage get es => const SvgGenImage('assets/images/svg/flags/es.svg');

  /// File path: assets/images/svg/flags/fr.svg
  SvgGenImage get fr => const SvgGenImage('assets/images/svg/flags/fr.svg');

  /// File path: assets/images/svg/flags/hi.svg
  SvgGenImage get hi => const SvgGenImage('assets/images/svg/flags/hi.svg');

  /// File path: assets/images/svg/flags/it.svg
  SvgGenImage get it => const SvgGenImage('assets/images/svg/flags/it.svg');

  /// File path: assets/images/svg/flags/ms.svg
  SvgGenImage get ms => const SvgGenImage('assets/images/svg/flags/ms.svg');

  /// File path: assets/images/svg/flags/ne.svg
  SvgGenImage get ne => const SvgGenImage('assets/images/svg/flags/ne.svg');

  /// File path: assets/images/svg/flags/nl.svg
  SvgGenImage get nl => const SvgGenImage('assets/images/svg/flags/nl.svg');

  /// File path: assets/images/svg/flags/pt.svg
  SvgGenImage get pt => const SvgGenImage('assets/images/svg/flags/pt.svg');

  /// File path: assets/images/svg/flags/tr.svg
  SvgGenImage get tr => const SvgGenImage('assets/images/svg/flags/tr.svg');

  /// File path: assets/images/svg/flags/ur.svg
  SvgGenImage get ur => const SvgGenImage('assets/images/svg/flags/ur.svg');

  /// List of all assets
  List<SvgGenImage> get values => [
    ar,
    bn,
    el,
    en,
    es,
    fr,
    hi,
    it,
    ms,
    ne,
    nl,
    pt,
    tr,
    ur,
  ];
}

abstract final class Assets {
  static const $AssetsImagesGen images = $AssetsImagesGen();
  static const $AssetsJsonGen json = $AssetsJsonGen();
}

class AssetGenImage {
  const AssetGenImage(
    this._assetName, {
    this.size,
    this.flavors = const {},
    this.animation,
  });

  final String _assetName;

  final Size? size;
  final Set<String> flavors;
  final AssetGenImageAnimation? animation;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = true,
    bool isAntiAlias = false,
    String? package,
    FilterQuality filterQuality = FilterQuality.medium,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({AssetBundle? bundle, String? package}) {
    return AssetImage(_assetName, bundle: bundle, package: package);
  }

  String get path => _assetName;

  String get keyName => _assetName;
}

class AssetGenImageAnimation {
  const AssetGenImageAnimation({
    required this.isAnimation,
    required this.duration,
    required this.frames,
  });

  final bool isAnimation;
  final Duration duration;
  final int frames;
}

class SvgGenImage {
  const SvgGenImage(this._assetName, {this.size, this.flavors = const {}})
    : _isVecFormat = false;

  const SvgGenImage.vec(this._assetName, {this.size, this.flavors = const {}})
    : _isVecFormat = true;

  final String _assetName;
  final Size? size;
  final Set<String> flavors;
  final bool _isVecFormat;

  _svg.SvgPicture svg({
    Key? key,
    bool matchTextDirection = false,
    AssetBundle? bundle,
    String? package,
    double? width,
    double? height,
    BoxFit fit = BoxFit.contain,
    AlignmentGeometry alignment = Alignment.center,
    bool allowDrawingOutsideViewBox = false,
    WidgetBuilder? placeholderBuilder,
    String? semanticsLabel,
    bool excludeFromSemantics = false,
    _svg.SvgTheme? theme,
    _svg.ColorMapper? colorMapper,
    ColorFilter? colorFilter,
    Clip clipBehavior = Clip.hardEdge,
    @deprecated Color? color,
    @deprecated BlendMode colorBlendMode = BlendMode.srcIn,
    @deprecated bool cacheColorFilter = false,
  }) {
    final _svg.BytesLoader loader;
    if (_isVecFormat) {
      loader = _vg.AssetBytesLoader(
        _assetName,
        assetBundle: bundle,
        packageName: package,
      );
    } else {
      loader = _svg.SvgAssetLoader(
        _assetName,
        assetBundle: bundle,
        packageName: package,
        theme: theme,
        colorMapper: colorMapper,
      );
    }
    return _svg.SvgPicture(
      loader,
      key: key,
      matchTextDirection: matchTextDirection,
      width: width,
      height: height,
      fit: fit,
      alignment: alignment,
      allowDrawingOutsideViewBox: allowDrawingOutsideViewBox,
      placeholderBuilder: placeholderBuilder,
      semanticsLabel: semanticsLabel,
      excludeFromSemantics: excludeFromSemantics,
      colorFilter:
          colorFilter ??
          (color == null ? null : ColorFilter.mode(color, colorBlendMode)),
      clipBehavior: clipBehavior,
      cacheColorFilter: cacheColorFilter,
    );
  }

  String get path => _assetName;

  String get keyName => _assetName;
}
