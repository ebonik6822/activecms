import 'package:customer/core/data/enums/app_module.dart';
import 'package:customer/features/common/data/models/language_model.dart';

class AppConstants {
  // API constants
  static const String baseUrl = 'https://your-server.com'; // AndroidManifest deeplink
  static const String itemDetailsRedirectPathSegment = 'item-details';
  static const AppModule defaultModule = AppModule.grocery;
  static const String appVersion = '4.2.0';

  // Auth constants
  static const String authAppleUri = '/api/v1/customer/auth/apple';
  static const String authGoogleUri = '/api/v1/customer/auth/google';
  static const String authFacebookUri = '/api/v1/customer/auth/facebook';
  static const String authRefreshUri = '/api/v1/customer/auth/refresh';
  static const String authLogoutUri = '/api/v1/customer/auth/logout';
  static const String authLoginUri = '/api/v1/customer/auth/login';
  static const String authForgotPasswordUri = '/api/v1/customer/auth/forgot-password';
  static const String authVerifyOtpUri = '/api/v1/customer/auth/verify-otp';
  static const String authResetPasswordUri = '/api/v1/customer/auth/reset-password';
  static const String authLoginWithOtpUri = '/api/v1/customer/auth/send-login-otp';
  static const String authLoginWithOtpVerifyUri = '/api/v1/customer/auth/verify-login-otp';
  static const String authCheckUserExistsUri = '/api/v1/customer/auth/check-user-exists';

  // Chatting
  static const String chatUri = '/api/v1/customer/chats';
  static const String notificationUri = '/api/v1/customer/notifications';

  // Profile
  static const String profileUri = '/api/v1/customer/profile';
  static const String profileFcmTokenUri = '/api/v1/customer/profile/fcm-token';
  static const String changePasswordUri = '/api/v1/customer/profile/change-password';
  static const String deleteAccountUri = '/api/v1/customer/profile/delete-account';

  // Home
  static const String homeUri = '/api/v1/customer/app-screen/home';
  static const String flashSalesUri = '/api/v1/customer/flash-sales';

  // Items
  static const String itemsUri = '/api/v1/customer/items';

  // Category
  static const String categoriesUri = '/api/v1/customer/categories';
  static const String categoriesPopularUri = '/api/v1/customer/categories/popular';

  // Brand
  static const String brandsPopularUri = '/api/v1/customer/brands/popular';

  // Label
  static const String labelsUri = '/api/v1/customer/labels';
  static const String commonConditionsUri = '/api/v1/customer/common-conditions';

  // Wishlist
  static const String wishlistUri = '/api/v1/customer/wishlist';

  // Offers
  static const String specialOfferUri = '/api/v1/customer/app-screen/special-offer';

  // Cart
  static const String cartUri = '/api/v1/customer/cart';
  static const String placeOrderUri = '/api/v1/customer/checkout/place-order';
  static const String applyDeliveryChargeUri = '/api/v1/customer/checkout/apply-delivery-charge';

  // Coupon
  static const String couponsUri = '/api/v1/customer/coupons';

  // Config
  static const String config = '/api/v1/customer/app-screen/config';

  // Settings
  static const String settings = '/api/v1/customer/profile/settings';

  // Address
  static const String addressUri = '/api/v1/customer/addresses';
  static const String geoCodeReverseUri = '/api/v1/customer/app-screen/geo-code-reverse';
  static const String placeAutocompleteUri = '/api/v1/customer/app-screen/place-autocomplete';
  static const String mapPlaceDetailsUri = '/api/v1/customer/app-screen/map-place-details';

  // Hub
  static const String locationResolveUri = '/api/v1/customer/location/resolve';
  static const String selectedHubId = 'selected_hub_id';
  static const String selectedHubData = 'selected_hub_data';

  // FAQ
  static const String faqUri = '/api/v1/customer/faqs';
  static const String faqCategoryUri = '/api/v1/customer/faqs/categories';

  // Order
  static const String orderUri = '/api/v1/customer/orders';
  static const String refundRequestUri = '/api/v1/customer/refund-requests';

  // Prescription
  static const String prescriptionUri = '/api/v1/customer/prescriptions';
  static const String prescriptionRequestUri = '/api/v1/customer/prescriptions/request';

  // Review
  static const String reviewsUri = '/api/v1/customer/reviews';

  // Wallet
  static const String addMoneyUri = '/api/v1/customer/wallet/add-money';
  static const String getWalletBalanceUri = '/api/v1/customer/wallet/show';

  // Loyalty Points
  static const String loyaltyPointConfigUri = '/api/v1/customer/loyalty-points/config';
  static const String loyaltyPointHistoriesUri = '/api/v1/customer/loyalty-points/histories';
  static const String loyaltyPointRedeemUri = '/api/v1/customer/loyalty-points/redeem';

  // Terms & Conditions
  static const String termsUri = '/api/v1/customer/app-screen/terms';

  // Privacy Policy
  static const String privacyUri = '/api/v1/customer/app-screen/privacy';

  // Refund Policy
  static const String refundPolicyUri = '/api/v1/customer/app-screen/refund-policy';

  // About Us
  static const String aboutUsUri = '/api/v1/customer/app-screen/about';

  // Item Content
  static const String itemContentUri = '/api/v1/customer/app-screen/item-content';

  //Contact Us
  static const String supportUri = '/api/v1/customer/app-screen/support';

  // Shared Key
  static const String loginType = 'login_type';
  static const String theme = 'theme_key';
  static const String languageCode = 'language_code';
  static const String guestUserId = 'guest_user_id';
  static const String currentUserId = 'current_user_id';
  static const String hasSeenOnboarding = 'hasSeenOnboarding';
  static const String isGuestUser = 'isGuestUser';
  static const String handledNotificationKey = 'last_handled_notification_id';
  static const String appModule = 'appModule';

  // FCM Topics
  static const String fcmTopicCustomerGroup = 'customer-group';
  static const String fcmTopicAllGeneral = 'all-general';

  // Pagination Limits
  static const int paginationLimitDefault = 10;
  static const int paginationLimitSmall = 5;
  static const int paginationLimitMedium = 6;

  static const String somethingWentWrong = "Something went wrong";

  static const String defaultLanguageCode = 'en';
  static final List<LanguageModel> languages = [
    LanguageModel(code: defaultLanguageCode, name: 'English', nativeName: 'English'),
    LanguageModel(code: 'es', name: 'Spanish', nativeName: 'español'),
    LanguageModel(code: 'ar', name: 'Arabic', nativeName: 'عربي'),
    LanguageModel(code: 'hi', name: 'Hindi', nativeName: 'हिंदी'),
    LanguageModel(code: 'bn', name: 'Bangla', nativeName: 'বাংলা'),
    LanguageModel(code: 'fr', name: 'French', nativeName: 'Français'),
    LanguageModel(code: 'ne', name: 'Nepali', nativeName: 'नेपाली'),
    LanguageModel(code: 'ur', name: 'Urdu', nativeName: 'اردو'),
    LanguageModel(code: 'it', name: 'Italian', nativeName: 'Italiano'),
    LanguageModel(code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu'),
    LanguageModel(code: 'nl', name: 'Dutch', nativeName: 'Nederlands'),
    LanguageModel(code: 'el', name: 'Greek', nativeName: 'Ελληνικά'),
    LanguageModel(code: 'tr', name: 'Turkish', nativeName: 'Türkçe'),
    LanguageModel(code: 'pt', name: 'Portuguese', nativeName: 'Português'),
  ];

  static const String otpSmsRegex = r"(\d{5})";

  static const String deleteAccountConfirmationKey = 'DELETE_MY_ACCOUNT';

  static const double responsiveMobileBreakPoint = 650;
  static const double responsiveDesktopBreakPoint = 1300;

  static const String chatType = 'customer_chats';

  // Notification Constants
  static const String notificationDefaultTitle = 'Notification';
  static const String notificationDefaultMessageTitle = 'New Message';
  static const String notificationDefaultMessageBody = 'You have a new message';
  static const String notificationDefaultChatName = 'Chat';
  static const String notificationAndroidIcon = '@mipmap/ic_launcher';
  static const String notificationChatIcon = '@drawable/ic_notification_chat';
  static const String notificationOrderIcon = '@drawable/ic_notification_order';
  static const String notificationChannelId = 'notifications_channel_id';
  static const String notificationChannelName = 'Notifications_channel_name';
  static const String notificationSound = 'notification';

  // Image constants
  static const List<String> supportedImageExtensions = ['jpg', 'jpeg', 'png'];
  static const int maxImageSizeBytes = 2 * 1024 * 1024; // 2MB

  // Prescription document constants (mirror backend pharmacy_settings defaults)
  static const List<String> prescriptionAllowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
  static const int prescriptionMaxFileSizeBytes = 5 * 1024 * 1024; // 5MB
  static const int prescriptionMaxDocuments = 10;
}
