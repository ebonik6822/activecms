import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:customer/config/util/app_constants.dart';
import 'package:customer/config/util/dimensions.dart';
import 'package:customer/config/util/styles.dart';
import 'package:customer/core/helper/bottom_sheet_extension.dart';
import 'package:customer/core/helper/extension_methods.dart';
import 'package:customer/core/helper/helpers.dart';
import 'package:customer/core/helper/l10n_keys.dart';
import 'package:customer/features/common/presentation/widgets/custom_snack_bar.dart';
import 'package:customer/features/prescription/presentation/widgets/prescription_add_document_button_widget.dart';
import 'package:customer/features/prescription/presentation/widgets/prescription_local_document_thumbnail_widget.dart';
import 'package:customer/features/prescription/presentation/widgets/prescription_source_selection_sheet_widget.dart';

class PrescriptionDocumentPickerWidget extends StatelessWidget {
  final List<String> documentPaths;
  final ValueChanged<List<String>> onChanged;

  const PrescriptionDocumentPickerWidget({
    super.key,
    required this.documentPaths,
    required this.onChanged,
  });

  Future<void> _showSourceSheet(BuildContext context) async {
    if (documentPaths.length >= AppConstants.prescriptionMaxDocuments) {
      context.customSnackBar(context.local.max_documents_reached, type: ToasterMessageType.error);
      return;
    }

    context.showBottomSheet(
      child: PrescriptionSourceSelectionSheetWidget(
        onCamera: () {
          Navigator.pop(context);
          _pickImage(context, ImageSource.camera);
        },
        onGallery: () {
          Navigator.pop(context);
          _pickImage(context, ImageSource.gallery);
        },
        onFile: () {
          Navigator.pop(context);
          _pickFiles(context);
        },
      ),
    );
  }

  Future<void> _pickFiles(BuildContext context) async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: AppConstants.prescriptionAllowedExtensions,
    );
    if (!context.mounted) return;
    final paths = result.map((file) => file.path).whereType<String>().toList();
    if (paths.isNotEmpty) _addPaths(context, paths);
  }

  Future<void> _pickImage(BuildContext context, ImageSource source) async {
    final result = await Helpers.pickAndCompressImage(source: source);
    if (!context.mounted) return;
    if (result.error != null) {
      context.customSnackBar(context.local.resolve(result.error!), type: ToasterMessageType.error);
      return;
    }
    if (result.image != null) {
      _addPath(context, result.image!.path);
    }
  }

  void _addPath(BuildContext context, String path) => _addPaths(context, [path]);

  void _addPaths(BuildContext context, List<String> paths) {
    final updated = [...documentPaths];
    bool hasUnsupported = false;
    bool hasOversize = false;
    bool reachedLimit = false;

    for (final path in paths) {
      final ext = p.extension(path).toLowerCase().replaceAll('.', '');
      if (!AppConstants.prescriptionAllowedExtensions.contains(ext)) {
        hasUnsupported = true;
        continue;
      }
      final file = File(path);
      if (file.existsSync() && file.lengthSync() > AppConstants.prescriptionMaxFileSizeBytes) {
        hasOversize = true;
        continue;
      }
      if (updated.length >= AppConstants.prescriptionMaxDocuments) {
        reachedLimit = true;
        break;
      }
      updated.add(path);
    }

    if (hasUnsupported) {
      context.customSnackBar(context.local.unsupported_file_format, type: ToasterMessageType.error);
    } else if (hasOversize) {
      context.customSnackBar(context.local.file_size_exceeds_limit, type: ToasterMessageType.error);
    } else if (reachedLimit) {
      context.customSnackBar(context.local.max_documents_reached, type: ToasterMessageType.error);
    }

    if (updated.length != documentPaths.length) onChanged(updated);
  }

  void _remove(int index) {
    final updated = [...documentPaths]..removeAt(index);
    onChanged(updated);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: Dimensions.paddingSizeSmall,
          runSpacing: Dimensions.paddingSizeSmall,
          children: [
            ...List.generate(
              documentPaths.length,
              (index) => PrescriptionLocalDocumentThumbnailWidget(
                path: documentPaths[index],
                onRemove: () => _remove(index),
              ),
            ),
            if (documentPaths.length < AppConstants.prescriptionMaxDocuments)
              PrescriptionAddDocumentButtonWidget(onTap: () => _showSourceSheet(context)),
          ],
        ),
        const SizedBox(height: Dimensions.paddingSizeExtraSmall),
        Text(
          '${documentPaths.length}/${AppConstants.prescriptionMaxDocuments}',
          style: regular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: context.theme.hintColor),
        ),
      ],
    );
  }
}
