allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
    afterEvaluate {
        extensions.findByName("android")?.let { ext ->
            val target = 37
            val setProperty = ext.javaClass.methods.firstOrNull {
                it.name == "setCompileSdk" && it.parameterCount == 1 && it.parameterTypes[0] == Integer::class.java
            }
            val setVersion = ext.javaClass.methods.firstOrNull {
                it.name == "compileSdkVersion" && it.parameterCount == 1 && it.parameterTypes[0] == Int::class.javaPrimitiveType
            }
            if (setProperty != null) setProperty.invoke(ext, target)
            else if (setVersion != null) setVersion.invoke(ext, target)
            else logger.warn("compileSdk override skipped for ${project.name}: no setter found")
        }
    }
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
